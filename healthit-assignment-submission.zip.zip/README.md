# HealthIT Assignment

## Overview
A Java application that fetches hospital data from the HealthIT.gov API and displays the state-wise percentage of eligible and Critical Access Hospitals that demonstrated Meaningful Use of CEHRT in 2014, sorted in descending order.

## Technologies Used
- Java 17
- Maven
- Jackson
- Docker

## Project Structure
```text
healthit-assignment/
├── src/
│   └── main/java/com/healthit/
│       ├── Main.java
│       ├── HospitalApiClient.java
│       ├── HospitalService.java
│       └── HospitalRecord.java
├── pom.xml
└── Dockerfile
```

## Build and Run

Build the application using Maven:

```bash
mvn clean package
```

Run the application:

```bash
java -jar target/healthit-assignment-1.0-SNAPSHOT.jar
```

## Docker

Build the Docker image:

```bash
docker build -t healthit-assignment .
```

Run the container:

```bash
docker run --name healthit-container healthit-assignment
```

## Dependencies
- Jackson Databind for JSON parsing.
- Maven for dependency management and building the executable JAR.

## Containerization
The application is containerized using Docker with the Eclipse Temurin Java 17 base image.