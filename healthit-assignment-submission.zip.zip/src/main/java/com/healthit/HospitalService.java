
package com.healthit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HospitalService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<HospitalRecord> get2014HospitalRecords(String jsonResponse)
             throws JsonProcessingException {

        List<HospitalRecord> records = objectMapper.readValue(
                jsonResponse,
                new TypeReference<List<HospitalRecord>>() {}
        );

        List<HospitalRecord> filteredRecords = new ArrayList<>();

        for (HospitalRecord record : records) {

            if ("2014".equals(record.getPeriod())
                    && !"National".equals(record.getRegion())
                    && record.getPctHospitalsMu() != null
                    && !record.getPctHospitalsMu().isBlank()) {

                filteredRecords.add(record);
            }
        }
        filteredRecords.sort(
                Comparator.comparingDouble(
                        (HospitalRecord record) ->
                                Double.parseDouble(record.getPctHospitalsMu())
                ).reversed()
        );

        return filteredRecords;
    }
}
