
package com.healthit;

import java.io.IOException;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        try {

            HospitalApiClient apiClient = new HospitalApiClient();
            String jsonResponse = apiClient.fetchHospitalData();
            HospitalService hospitalService = new HospitalService();

            List<HospitalRecord> records =
                    hospitalService.get2014HospitalRecords(jsonResponse);


            System.out.println("Total 2014 state records: " + records.size());

            System.out.println("\nHospital Meaningful Use by State (2014):");

            for (HospitalRecord record : records) {

                double percentage =
                        Double.parseDouble(record.getPctHospitalsMu()) * 100;

                System.out.printf("%-25s %.2f%%%n",
                        record.getRegion(),
                        percentage);
            }

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
            System.err.println("API request was interrupted.");

        } catch (IOException e) {

            System.err.println(
                    "Unable to fetch or process hospital data: " + e.getMessage()
            );
        }
    }
}
