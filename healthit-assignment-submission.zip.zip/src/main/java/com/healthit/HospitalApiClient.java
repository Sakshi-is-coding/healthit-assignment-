
package com.healthit;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HospitalApiClient {

    private static final String API_URL =
            "https://healthit.gov/data/open-api?source=Meaningful-Use-Acceleration-Scorecard.csv";

    public String fetchHospitalData()
            throws IOException, InterruptedException {

        HttpClient client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(API_URL))
                .GET()
                .build();

        HttpResponse<String> response = client.send(
                request,
                HttpResponse.BodyHandlers.ofString()
        );

        if (response.statusCode() != 200) {
            throw new RuntimeException(
                    "API request failed. Status: " + response.statusCode()
            );
        }

        return response.body();
    }
}
