
package com.healthit;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HospitalRecord {

    private String region;
    private String period;

    @JsonProperty("pct_hospitals_mu")
    private String pctHospitalsMu;

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getPctHospitalsMu() {
        return pctHospitalsMu;
    }

    public void setPctHospitalsMu(String pctHospitalsMu) {
        this.pctHospitalsMu = pctHospitalsMu;
    }
}
